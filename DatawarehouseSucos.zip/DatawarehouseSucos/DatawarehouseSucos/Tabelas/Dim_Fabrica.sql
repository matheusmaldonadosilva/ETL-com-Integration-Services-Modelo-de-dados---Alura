﻿CREATE TABLE [dbo].[Dim_Fabrica]
(
	[Cod_Fabrica] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [Desc_Fabrica] NVARCHAR(200) NULL
)
