﻿CREATE TABLE [dbo].[Dim_Categoria]
(
	[Cod_Categoria] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [Desc_Categoria] NVARCHAR(200) NULL
)
